package com.first.thewatch.ui.home;

import androidx.lifecycle.ViewModel;

public class AddContactViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}