package com.first.thewatch.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.first.thewatch.DatabaseHelper;
import com.first.thewatch.R;
import com.google.firebase.messaging.FirebaseMessaging;

public class FCMTokenFragment extends Fragment {

    private TextView textViewToken;
    private Button buttonGenerateToken;
    private DatabaseHelper databaseHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fcm_token, container, false);

        textViewToken = view.findViewById(R.id.textViewToken);
        buttonGenerateToken = view.findViewById(R.id.buttonGenerateToken);
        databaseHelper = new DatabaseHelper(requireContext());

        buttonGenerateToken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateAndSaveToken();
            }
        });

        // Retrieve and display token from the database
        String token = getFCMTokenFromDatabase();
        textViewToken.setText(token != null ? token : getString(R.string.token_not_available));

        return view;
    }

    private void generateAndSaveToken() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        textViewToken.setText(getString(R.string.token_generation_failed));
                        return;
                    }

                    // Get new FCM token
                    String token = task.getResult();
                    textViewToken.setText(token);
                    saveTokenToDatabase(token);
                });
    }

    private void saveTokenToDatabase(String token) {
        long result = databaseHelper.saveFCMToken(token);
        if (result != -1) {
            // Token saved successfully
            // You can add further actions if needed
        } else {
            // Failed to save token
            // You can add error handling if needed
        }
    }

    private String getFCMTokenFromDatabase() {
        // Retrieve token from the database
        return databaseHelper.getSavedFCMToken();
    }
}
