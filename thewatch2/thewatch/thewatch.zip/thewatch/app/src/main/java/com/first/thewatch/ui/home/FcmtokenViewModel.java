package com.first.thewatch.ui.home;

import androidx.lifecycle.ViewModel;

public class FcmtokenViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}